package com.example.version;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class PaginawebActivity extends AppCompatActivity {

    WebView Web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.paginaweb);
        WebView web = (WebView) this.findViewById(R.id.web);
        web.loadUrl("https://www.google.com/");
        web.setWebViewClient(new WebViewClient());
    }
}